import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'add-product',
    templateUrl: 'add-product.component.html'
})

export class AddProductComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}