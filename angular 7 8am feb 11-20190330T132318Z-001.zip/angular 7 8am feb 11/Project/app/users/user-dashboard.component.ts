import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'user-dashboard',
    templateUrl: 'user-dashboard.component.html'
})

export class UserDashBoardComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}