import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'store-main',
    templateUrl: 'store-main.component.html',
    styleUrls:['store-main.component.css']
})

export class StoreMainComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}