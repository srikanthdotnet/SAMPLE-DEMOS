import { Injectable } from '@angular/core';

@Injectable()
export class Service4 {

    constructor() { 
        console.log("i am in service4");
    }
}