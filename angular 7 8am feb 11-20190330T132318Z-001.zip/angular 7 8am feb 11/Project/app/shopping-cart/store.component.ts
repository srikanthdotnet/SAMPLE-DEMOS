import { Component, OnInit } from '@angular/core';
import * as $ from "jquery";
@Component({
    selector: 'store',
    templateUrl: 'store.component.html'
})

export class StoreComponent{

    constructor(){
    }
    
}