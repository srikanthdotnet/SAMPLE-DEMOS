import { Cart } from './cart';
export class Order{
    id;
    cart:Cart;
    orderDate:Date;
    
}