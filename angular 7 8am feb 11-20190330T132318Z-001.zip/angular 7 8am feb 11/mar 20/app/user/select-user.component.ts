import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'select-user',
    templateUrl: 'select-user.component.html'
})

export class SelectUserComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}