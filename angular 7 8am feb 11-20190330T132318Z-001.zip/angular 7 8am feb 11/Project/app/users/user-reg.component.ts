import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'user-reg',
    templateUrl: 'user-reg.component.html'
})

export class UserRegComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}