import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'display-product',
    templateUrl: 'display-product.component.html'
})

export class DisplayProductComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}