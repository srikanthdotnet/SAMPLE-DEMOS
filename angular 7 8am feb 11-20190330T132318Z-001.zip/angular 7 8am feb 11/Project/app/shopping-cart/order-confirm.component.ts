import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'order-confirm',
    templateUrl: 'order-confirm.component.html'
})

export class OrderConfirmComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}