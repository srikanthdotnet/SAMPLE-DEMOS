var mssql = require("mssql");

mssql.connect(config,function(err){

});