import { Injectable } from '@angular/core';

@Injectable()
export class Service1 {

    constructor() { 
        console.log("i am in service1");
    }
}