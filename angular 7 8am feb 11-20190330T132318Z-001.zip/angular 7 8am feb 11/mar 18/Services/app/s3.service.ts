import { Injectable } from '@angular/core';

@Injectable()
export class Service3 {

    constructor() { 
        console.log("i am in service3");
    }
}