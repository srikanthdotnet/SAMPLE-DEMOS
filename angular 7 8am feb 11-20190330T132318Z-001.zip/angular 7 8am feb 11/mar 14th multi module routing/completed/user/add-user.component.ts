import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'add-user',
    templateUrl: 'add-user.component.html'
})

export class AddUserComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}