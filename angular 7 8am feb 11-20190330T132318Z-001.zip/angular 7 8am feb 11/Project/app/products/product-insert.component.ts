import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'product-insert',
    templateUrl: 'product-insert.component.html'
})

export class ProductInsertComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}