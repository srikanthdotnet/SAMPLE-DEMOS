export class User{
    id:number;
    username:string;
    password:string;
    email:string;
    phoneNo:string;
    role:string;
}